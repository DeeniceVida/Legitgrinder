-- Clear all product records for fresh start
DELETE FROM products;
