
import { supabase } from '../lib/supabase';
import { PricelistItem, Product, Availability, Client, Consultation, ConsultationStatus } from '../../types';
import { calculateAutomatedPrice } from '../../utils/priceCalculations';

export const fetchPricelistData = async (): Promise<PricelistItem[]> => {
    try {
        const { data: variants, error } = await supabase
            .from('product_variants')
            .select(`
        id,
        capacity,
        price_usd,
        price_kes,
        last_updated,
        source_url,
        products (
          id,
          name,
          brand,
          series
        )
      `)
            .eq('status', 'active');

        if (error) throw error;

        // Group variants by product
        const groupedData: Record<string, PricelistItem> = {};

        variants?.forEach((v: any) => {
            const product = v.products;
            if (!product) return;

            if (!groupedData[product.id]) {
                groupedData[product.id] = {
                    id: product.id,
                    modelName: product.name,
                    brand: product.brand as 'iphone' | 'samsung' | 'pixel',
                    series: product.series,
                    capacities: [],
                    syncAlert: false,
                    sourceUrl: v.source_url
                };
            }

            groupedData[product.id].capacities.push({
                capacity: v.capacity,
                currentPriceKES: v.price_kes || 0,
                previousPriceKES: 0, // Could be handled by adding previous_price_kes to query
                lastSynced: v.last_updated ? new Date(v.last_updated).toLocaleString() : 'Never',
                sourcePriceUSD: v.price_usd || 0,
                isManualOverride: false // This flag should ideally come from the DB as well
            });
        });

        return Object.values(groupedData);
    } catch (error) {
        console.error('Error fetching pricelist:', error);
        return [];
    }
};

export const fetchInventoryProducts = async (): Promise<Product[]> => {
    try {
        const { data, error } = await supabase
            .from('products')
            .select('*')
            // Filter to only get shop products, not pricelist source products
            // Based on migration_products_v4.sql, we can use category or just check for shop-specific fields
            .not('price_kes', 'is', null);

        if (error) throw error;

        return data.map((p: any) => ({
            id: p.id.toString(),
            name: p.name,
            priceKES: parseFloat(p.price_kes),
            discountPriceKES: p.discount_price ? parseFloat(p.discount_price) : undefined,
            imageUrls: p.images && p.images.length > 0 ? p.images : [p.image || 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&q=80&w=800'],
            variations: p.shop_variants || [],
            availability: p.stock_status as Availability,
            shippingDuration: p.shipping_duration || '2-3 Business Days',
            description: p.description || '',
            category: p.category || 'Electronics',
            stockCount: parseInt(p.inventory_quantity || 0)
        }));
    } catch (error) {
        console.error('Error fetching inventory:', error);
        return [];
    }
};

export const fetchClientsData = async (): Promise<Client[]> => {
    try {
        const { data, error } = await supabase
            .from('clients')
            .select('*');

        if (error) throw error;

        return data.map((c: any) => ({
            id: c.id,
            name: c.name,
            email: c.email,
            phone: c.phone || '',
            location: c.location || '',
            joinedDate: c.joined_date,
            totalSpentKES: parseFloat(c.total_spent_kes || 0),
            orderCount: parseInt(c.order_count || 0),
            lastOrderDate: c.last_order_date || 'Never',
            interests: c.interests || [],
            purchasedItems: c.purchased_items || [],
            purchaseFrequency: c.purchase_frequency as any || 'Low'
        }));
    } catch (error) {
        console.error('Error fetching clients:', error);
        return [];
    }
};

export const saveClientToSupabase = async (client: Client): Promise<{ success: boolean; error?: any }> => {
    try {
        const { error } = await supabase
            .from('clients')
            .upsert({
                id: client.id,
                name: client.name,
                email: client.email,
                phone: client.phone,
                location: client.location,
                joined_date: client.joinedDate,
                total_spent_kes: client.totalSpentKES,
                order_count: client.orderCount,
                last_order_date: client.lastOrderDate,
                interests: client.interests,
                purchased_items: client.purchasedItems,
                purchase_frequency: client.purchaseFrequency
            });

        if (error) throw error;
        return { success: true };
    } catch (error) {
        console.error('Error saving client:', error);
        return { success: false, error };
    }
};

export const saveConsultation = async (consultation: Omit<Consultation, 'id' | 'status' | 'feeUSD'>): Promise<{ success: boolean; data?: any; error?: any }> => {
    try {
        const { data, error } = await supabase
            .from('consultations')
            .insert({
                name: consultation.name,
                email: consultation.email,
                phone: consultation.phone,
                whatsapp: consultation.whatsapp,
                date: consultation.date,
                time: consultation.time,
                topic: consultation.topic
            })
            .select()
            .single();

        if (error) throw error;
        return { success: true, data };
    } catch (error) {
        console.error('Error saving consultation:', error);
        return { success: false, error };
    }
};

export const fetchConsultations = async (): Promise<Consultation[]> => {
    try {
        const { data, error } = await supabase
            .from('consultations')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;

        return data.map((c: any) => ({
            id: c.id,
            name: c.name,
            email: c.email,
            phone: c.phone,
            whatsapp: c.whatsapp,
            date: c.date,
            time: c.time,
            topic: c.topic,
            status: c.status as ConsultationStatus,
            feeUSD: parseFloat(c.fee_usd || 15)
        }));
    } catch (error) {
        console.error('Error fetching consultations:', error);
        return [];
    }
};

export const updateConsultationStatus = async (id: string, status: ConsultationStatus): Promise<boolean> => {
    try {
        const { error } = await supabase
            .from('consultations')
            .update({ status })
            .eq('id', id);

        if (error) throw error;
        return true;
    } catch (error) {
        console.error('Error updating consultation status:', error);
        return false;
    }
};

export const updateProduct = async (product: Product): Promise<boolean | string> => {
    try {
        alert('Supabase Service: Starting update for ID ' + product.id);
        const { error, count } = await supabase
            .from('products')
            .update({
                name: product.name,
                price_kes: product.priceKES,
                discount_price: product.discountPriceKES,
                images: product.imageUrls,
                stock_status: product.availability,
                shipping_duration: product.shippingDuration,
                description: product.description,
                category: product.category,
                inventory_quantity: product.stockCount,
                shop_variants: product.variations
            }, { count: 'exact' })
            .eq('id', parseInt(product.id));

        if (error) {
            alert('Supabase Service: ERROR - ' + error.message);
            console.error('Supabase Update Error:', error);
            return error.message;
        }

        alert('Supabase Service: DONE. Count = ' + count);
        if (count === 0) return 'Product not found (ID: ' + product.id + ')';
        return true;
    } catch (error: any) {
        alert('Supabase Service: CATCH - ' + (error.message || 'Unknown error'));
        console.error('Error updating product:', error);
        return error.message || 'Unknown database error';
    }
};
